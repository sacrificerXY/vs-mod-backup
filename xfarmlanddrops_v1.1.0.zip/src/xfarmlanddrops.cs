﻿using System;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace XFarmlandDrops
{
    class XFarmlandDropsSystem : ModSystem
    {
        public override void Start(ICoreAPI api)
        {
            base.Start(api);
            api.RegisterBlockBehaviorClass("XFarmlandDrop", typeof(XFarmlandDrop));
        }
    }

    public class XFarmlandDrop : BlockBehavior
    {
        public XFarmlandDrop(Block block) : base(block)
        { }

        public override ItemStack[] GetDrops(IWorldAccessor world, BlockPos pos, IPlayer byPlayer, ref float dropChanceMultiplier, ref EnumHandling handling)
        {
            IFarmlandBlockEntity farmlandBlock = world.BlockAccessor.GetBlockEntity(pos) as IFarmlandBlockEntity;
            if (farmlandBlock == null)
            {
                return base.GetDrops(world, pos, byPlayer, ref dropChanceMultiplier, ref handling);
            }

            float minNutrients = Math.Min(farmlandBlock.Nutrients[0], Math.Min(farmlandBlock.Nutrients[1], farmlandBlock.Nutrients[2]));
            minNutrients = Math.Min(minNutrients, farmlandBlock.OriginalFertility);
            AssetLocation assetLocation;

            if (minNutrients >= 79)
            {
                assetLocation = new AssetLocation("game", "soil-high-none");
            }
            else if (minNutrients >= 64)
            {
                assetLocation = new AssetLocation("game", "soil-compost-none");
            }
            else if (minNutrients >= 49)
            {
                assetLocation = new AssetLocation("game", "soil-medium-none");
            }
            else if (minNutrients >= 24)
            {
                assetLocation = new AssetLocation("game", "soil-low-none");
            }
            else
            {
                assetLocation = new AssetLocation("game", "soil-verylow-none");
            }

            Block block = world.GetBlock(assetLocation);
            if (block == null) return base.GetDrops(world, pos, byPlayer, ref dropChanceMultiplier, ref handling);
            handling = EnumHandling.PreventDefault;
            ItemStack[] drops = new ItemStack[1];
            drops[0] = new ItemStack(block, 1);
            return drops;
        }

    }//!class XFarmlandDrop
}//!namespace XFarmlandDrops
