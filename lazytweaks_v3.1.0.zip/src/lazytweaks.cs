﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;


namespace WarlockMods
{
    public class LazyTweaks: ModSystem //This is the Mod Class
    {
        public override void Start(ICoreAPI api) //Start Method that uses an API
        {
            base.Start(api);

            //For now, this just functions as a mod so that actual classes can be used

            //api.RegisterBlockClass("waterstone", typeof(WhetstoneBlock));
            //api.RegisterItemClass("whetstone", typeof(ItemWhetstone)); //make sure to register with the class file name

        }
    }
}